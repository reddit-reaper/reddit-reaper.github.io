# -*- coding: utf-8 -*-

import torrent

def get_torrent():
    return torrent.__all__